package assignment1;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;


public class PracticeFormNegative {

	public static void main(String[] args) throws Exception {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\edrak\\workspace\\proj1\\chromedriver_win32\\chromedriver.exe"); 
		WebDriver driver=new ChromeDriver();
		JavascriptExecutor js = (JavascriptExecutor) driver;
		driver.manage().window().maximize();
		driver.get("https://demoqa.com/automation-practice-form");
		
		WebElement firstname=driver.findElement(By.xpath("//input[@id='firstName']"));
		firstname.sendKeys("");
		Thread.sleep(1000);
		WebElement lastname=driver.findElement(By.xpath("//input[@id='lastName']"));
		lastname.sendKeys("");
		Thread.sleep(1000);

		Thread.sleep(1000);
		WebElement mobile=driver.findElement(By.xpath("//*[@id='userNumber']"));
		mobile.sendKeys("");
		Thread.sleep(1000);
		WebElement subjects=driver.findElement(By.xpath("//*[@id='subjectsInput']"));
		subjects.sendKeys("");
		Thread.sleep(1000);
	
		WebElement State=driver.findElement(By.xpath("//*[@id='react-select-3-input']"));
		State.sendKeys("");
		Thread.sleep(1000);


		WebElement sb=driver.findElement(By.id("submit"));
		sb.submit();
		Thread.sleep(1000);
		js.executeScript("arguments[0].scrollIntoView();",mobile);
		WebElement header=driver.findElement(By.xpath("//*[@id='app']/div/div/div[2]/div[2]/div[1]/h5"));
		Thread.sleep(1000);
		js.executeScript("arguments[0].scrollIntoView();",header);

		Thread.sleep(3000);
		driver.close();
			}

}
