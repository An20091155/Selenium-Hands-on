package assignment1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Selectable {

	public static void main(String[] args) throws Exception {
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\edrak\\workspace\\proj1\\chromedriver_win32\\chromedriver.exe"); 
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://demoqa.com/selectable/");
		//List 
		WebElement item1=driver.findElement(By.xpath("//*[@id='verticalListContainer']/li[1]"));
		item1.click();
		System.out.println("Cras justo odio");
		Thread.sleep(1000);
		WebElement item2=driver.findElement(By.xpath("//*[@id='verticalListContainer']/li[2]"));
		item2.click();
		System.out.println("Dapibus ac facilisis in");
		Thread.sleep(1000);
		WebElement item3=driver.findElement(By.xpath("//*[@id='verticalListContainer']/li[3]"));
		item3.click();
		System.out.println("Morbi leo risus");
		Thread.sleep(1000);
		WebElement item4=driver.findElement(By.xpath("//*[@id='verticalListContainer']/li[4]"));
		item4.click();
		System.out.println("Porta ac consectetur ac");
		Thread.sleep(2000);
		
		//Grid 
		WebElement grid=driver.findElement(By.id("demo-tab-grid"));
		grid.click();
		Thread.sleep(1000);
		WebElement item5=driver.findElement(By.xpath("//*[@id='row1']/li[1]"));
		item5.click();
		System.out.println("One");
		Thread.sleep(1000);
		WebElement item6=driver.findElement(By.xpath("//*[@id='row1']/li[2]"));
		item6.click();
		System.out.println("Two");
		Thread.sleep(1000);
		WebElement item7=driver.findElement(By.xpath("//*[@id='row1']/li[3]"));
		item7.click();
		System.out.println("Three");
		Thread.sleep(1000);
		WebElement item8=driver.findElement(By.xpath("//*[@id='row2']/li[1]"));
		item8.click();
		System.out.println("Four");
		Thread.sleep(1000);
		WebElement item9=driver.findElement(By.xpath("//*[@id='row2']/li[2]"));
		item9.click();
		System.out.println("Five");
		Thread.sleep(1000);
		WebElement item10=driver.findElement(By.xpath("//*[@id='row2']/li[3]"));
		item10.click();
		System.out.println("Six");
		Thread.sleep(1000);
		WebElement item11=driver.findElement(By.xpath("//*[@id='row3']/li[1]"));
		item11.click();
		System.out.println("Seven");
		Thread.sleep(1000);
		WebElement item12=driver.findElement(By.xpath("//*[@id='row3']/li[2]"));
		item12.click();
		System.out.println("Eight");
		Thread.sleep(1000);
		WebElement item13=driver.findElement(By.xpath("//*[@id='row3']/li[3]"));
		item13.click();
		System.out.println("Nine");
		
		
		Thread.sleep(3000);
		driver.close();
	}

}
