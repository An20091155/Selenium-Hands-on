package assignment1;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;


public class PracticeFormPositive {

	public static void main(String[] args) throws Exception {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\edrak\\workspace\\proj1\\chromedriver_win32\\chromedriver.exe"); 
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://demoqa.com/automation-practice-form");
		
		WebElement firstname=driver.findElement(By.xpath("//input[@id='firstName']"));
		firstname.sendKeys("anwar9");
		Thread.sleep(1000);
		WebElement lastname=driver.findElement(By.xpath("//input[@id='lastName']"));
		lastname.sendKeys("moh");
		Thread.sleep(1000);
		WebElement gender=driver.findElement(By.xpath("//*[@id='genterWrapper']/div[2]/div[2]/label"));
		gender.click();
		Thread.sleep(1000);
		WebElement mobile=driver.findElement(By.xpath("//*[@id='userNumber']"));
		mobile.sendKeys("0123456789");
		Thread.sleep(1000);
		WebElement subjects=driver.findElement(By.xpath("//*[@id='subjectsInput']"));
		subjects.sendKeys("English");
		Thread.sleep(1000);
		subjects.sendKeys(Keys.ENTER);
		subjects.sendKeys("Ch");
		Thread.sleep(1000);
		subjects.sendKeys(Keys.ENTER);
		WebElement State=driver.findElement(By.xpath("//*[@id='react-select-3-input']"));
		State.sendKeys("NCR");
		Thread.sleep(1000);
		State.sendKeys(Keys.ENTER);
		WebElement City=driver.findElement(By.xpath("//*[@id='react-select-4-input']"));
		City.sendKeys("Noida");
		Thread.sleep(1000);
		City.sendKeys(Keys.ENTER);
		Thread.sleep(1000);
		WebElement sb=driver.findElement(By.id("submit"));
		sb.submit();
		
		Thread.sleep(3000);
		driver.close();
			}

}
