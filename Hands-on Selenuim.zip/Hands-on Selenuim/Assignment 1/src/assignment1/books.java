package assignment1;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class books {

	public static void main(String[] args) throws Exception {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\edrak\\workspace\\proj1\\chromedriver_win32\\chromedriver.exe"); 
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://demoqa.com/books");
		WebElement searchValue=driver.findElement(By.id("searchBox"));
		searchValue.sendKeys("You Don't Know JS");
		Thread.sleep(3000);
		WebElement viewbook=driver.findElement(By.linkText("You Don't Know JS"));
		viewbook.click();
		Thread.sleep(5000);
		driver.close();
	}
	
}
