package assignment1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class droppablePositive {

	public static void main(String[] args) throws Exception {
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\edrak\\workspace\\proj1\\chromedriver_win32\\chromedriver.exe"); 
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://demoqa.com/droppable/");
		
		
		Actions builder = new Actions(driver);
		WebElement dragbox = driver.findElement(By.id("draggable"));
		WebElement dropbox = driver.findElement(By.id("droppable")); 
		//Perform drag and drop
		builder.dragAndDrop(dragbox , dropbox).perform();
		//verify text changed in to 'Drop here' box 
		String textDropbox = dropbox.getText();
		if(textDropbox.equals("Dropped!")) {
		System.out.println("PASS: The box is dropped to target as expected");
		}else {
		System.out.println("FAIL: The box couldn't be dropped to target as expected");
		}
		
		Thread.sleep(3000);
		driver.close();
		
		
	}

}
