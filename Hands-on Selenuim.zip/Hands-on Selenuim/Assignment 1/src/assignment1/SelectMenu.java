package assignment1;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class SelectMenu {

	public static void main(String[] args) throws Exception {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\edrak\\workspace\\proj1\\chromedriver_win32\\chromedriver.exe"); 
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://demoqa.com/select-menu");
		WebElement selectValue=driver.findElement(By.xpath("//*[@id='react-select-2-input']"));
		selectValue.sendKeys("Group 1");
		Thread.sleep(1000);
		selectValue.sendKeys(Keys.ENTER);
		WebElement selectOne=driver.findElement(By.xpath("//*[@id='react-select-3-input']"));
		selectOne.sendKeys("Ms");
		Thread.sleep(1000);
		selectOne.sendKeys(Keys.ENTER);
		Select se = new Select(driver.findElement(By.id("oldSelectMenu")));
		se.selectByVisibleText("Green");
		WebElement Multiselect =driver.findElement(By.xpath("//*[@id='react-select-4-input']"));
		Multiselect.sendKeys("Green");
		Thread.sleep(1000);
		Multiselect.sendKeys(Keys.ENTER);
		Multiselect.sendKeys("Red");
		Thread.sleep(1000);
		Multiselect.sendKeys(Keys.ENTER);
		Select multipleName = new Select(driver.findElement(By.id("cars")));
	
		if(multipleName.isMultiple()){
			multipleName.selectByValue("Opel");
			multipleName.selectByValue("volvo");
		}
		
		Thread.sleep(3000);
		driver.close();
	}
	
}
