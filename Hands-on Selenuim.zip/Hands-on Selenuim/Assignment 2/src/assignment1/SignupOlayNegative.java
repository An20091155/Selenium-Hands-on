package assignment1;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;


public class SignupOlayNegative {

	public static void main(String[] args) throws Exception {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\edrak\\workspace\\proj1\\chromedriver_win32\\chromedriver.exe"); 
		WebDriver driver=new ChromeDriver();
   	JavascriptExecutor js = (JavascriptExecutor) driver;
		driver.manage().window().maximize();
		driver.get("https://www.olay.com/login.php");
		
		WebElement element=driver.findElement(By.xpath("//*[@id='main-content']/div/div[2]/div/form"));
	   js.executeScript("arguments[0].scrollIntoView();",element);
		
	//CREATE AN ACCOUNT 	
		WebElement Signup=driver.findElement(By.xpath("//*[@id='main-content']/div/div[2]/div/form/div[3]/div[1]/a"));

		Thread.sleep(2000);
		Signup.click();
	
	
		//First Name Field 
		WebElement firstName=driver.findElement(By.xpath("//input[@id='FormField_4_input']"));
		firstName.sendKeys("");
		Thread.sleep(2000);
		//Last Name Field
		WebElement lastName=driver.findElement(By.xpath("//input[@id='FormField_5_input']"));
		lastName.sendKeys("");
		Thread.sleep(2000);
	    //Post-code  Field
		WebElement postcode=driver.findElement(By.xpath("//input[@id='FormField_13_input']"));
		postcode.sendKeys("");
		Thread.sleep(2000);
		 //Email Field
		WebElement mail=driver.findElement(By.xpath("//*[@id='FormField_1_input']"));
		mail.sendKeys("");
		Thread.sleep(2000);
		 //Password Field
		WebElement password=driver.findElement(By.xpath("//*[@id='FormField_2_input']"));
		password.sendKeys("");
		Thread.sleep(2000);
		//Confirm Password Field
	    WebElement conPassword=driver.findElement(By.xpath("//input[@id='FormField_3_input']"));
	    conPassword.sendKeys("");
		Thread.sleep(2000);
		
		//Birth-date Fields
		Select month=new Select(driver.findElement(By.id("FormField_25_month")));
	    month.selectByValue("9");
		Thread.sleep(2000);
		Select year=new Select(driver.findElement(By.id("FormField_25_year")));
		year.selectByVisibleText("1991");
		Thread.sleep(2000);
		

		
	    WebElement join=driver.findElement(By.xpath("//*[@id='createForm']/div[14]/input"));
	    join.click();
	  
		Thread.sleep(3000);
		driver.close();
			}
}
