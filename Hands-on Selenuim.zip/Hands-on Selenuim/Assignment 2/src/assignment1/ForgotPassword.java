package assignment1;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;


public class ForgotPassword {

	public static void main(String[] args) throws Exception {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\edrak\\workspace\\proj1\\chromedriver_win32\\chromedriver.exe"); 
		WebDriver driver=new ChromeDriver();
   
		driver.manage().window().maximize();
		//LOGIN TO ACCOUNT
		driver.get("https://www.olay.com/login.php");
		Thread.sleep(2000);
		//Email Address
		WebElement emailAddress=driver.findElement(By.xpath("//input[@id='login_email']"));
		emailAddress.sendKeys("abc@mail.com");
		Thread.sleep(2000);
		//Password
		WebElement password=driver.findElement(By.xpath("//input[@id='login_pass']"));
		password.sendKeys("3662");
		Thread.sleep(2000);
	
		
	    WebElement login=driver.findElement(By.xpath("//*[@id='main-content']/div/div[2]/div/form/div[3]/input"));
	    login.click();
	    Thread.sleep(4000);
	    WebElement forgotpw=driver.findElement(By.xpath("//*[@id='main-content']/div/div[2]/div/form/a"));
	    forgotpw.click();
	  
	    WebElement email=driver.findElement(By.xpath("//*[@id='email']"));
	    email.sendKeys("abc@mail.com");
	    
	    WebElement reset=driver.findElement(By.xpath(" //*[@id='main-content']/div/div/form/div/input[2]"));
	    reset.click();
	  
//		Thread.sleep(3000);
//		driver.close();
			}
}
