package Assinment2;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import io.github.bonigarcia.wdm.WebDriverManager;

public class RegisterDifferentIDs {

	public static void main(String[] args) throws IOException, Exception {
   WebDriverManager.chromedriver().setup();
   WebDriver driver=new ChromeDriver();
   driver.manage().window().maximize();
   driver.get("https://www.olay.com/login.php?action=create_account");
   
   File file =new File("C:\\Users\\edrak\\workspace\\proj1\\TestData\\TestData.xls");   
   
   FileInputStream inputStream = new FileInputStream(file);
   
   HSSFWorkbook wb=new HSSFWorkbook(inputStream);
   HSSFSheet sheet=wb.getSheet("Sheet1");
   int rowCount=sheet.getLastRowNum()-sheet.getFirstRowNum();
   
	WebElement firstName=driver.findElement(By.xpath("//input[@id='FormField_4_input']"));
	WebElement lastName=driver.findElement(By.xpath("//input[@id='FormField_5_input']"));
	WebElement postcode=driver.findElement(By.xpath("//input[@id='FormField_13_input']"));
	WebElement mail=driver.findElement(By.xpath("//*[@id='FormField_1_input']"));
	WebElement password=driver.findElement(By.xpath("//*[@id='FormField_2_input']"));
	WebElement conPassword=driver.findElement(By.xpath("//input[@id='FormField_3_input']"));
	Select month=new Select(driver.findElement(By.id("FormField_25_month")));
	Select year=new Select(driver.findElement(By.id("FormField_25_year")));
	
	 for(int i=1;i<=rowCount;i++) {
//		 String data0=String.valueOf(sheet.getRow(i).getCell(2).getNumericCellValue());
		
		 firstName.sendKeys(sheet.getRow(i).getCell(0).getStringCellValue());
		 lastName.sendKeys(sheet.getRow(i).getCell(1).getStringCellValue());
		 
		 postcode.sendKeys(sheet.getRow(i).getCell(2).getStringCellValue());
		 mail.sendKeys(sheet.getRow(i).getCell(3).getStringCellValue());
		 password.sendKeys(sheet.getRow(i).getCell(4).getStringCellValue());
		 conPassword.sendKeys(sheet.getRow(i).getCell(5).getStringCellValue());
		 month.selectByVisibleText(sheet.getRow(i).getCell(6).getStringCellValue());
		 year.selectByVisibleText(sheet.getRow(i).getCell(7).getStringCellValue());
			Thread.sleep(9000);
	 }
	 
	
	
	
	
	
	
	
	
	

	}

}
