package assignment1;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;



public class Trip {

	public static void main(String[] args) throws InterruptedException {
		//Step 1:Launch Make my trip website ( makemytrip.com)													
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\edrak\\workspace\\proj1\\chromedriver_win32\\chromedriver.exe"); 
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.makemytrip.com/");
		Thread.sleep(4000);
		//Step 2: Select any one option( Oneway ,Roundtrip,Multi City)													
		//OneWay
		driver.findElement(By.xpath("//li[contains(text(),'OneWay')]/span")).click();
		//Step 3: Select From & To													
		//FROM
		driver.findElement(By.xpath("//div[@class='fsw_inputBox searchCity inactiveWidget activeWidget']/label")).click();
		driver.findElement(By.xpath("//div[@class='hsw_autocomplePopup autoSuggestPlugin ']/div/input")).sendKeys("Riyadh");
		List<WebElement> listcites=driver.findElements(By.cssSelector("p[class='font14 appendBottom5 blackText']"));
    for(int i=0;i<listcites.size();i++) {
    	String text=listcites.get(i).getText();
    	if(text.contains("Ryiadh")){
    		listcites.get(i).click();
    		break;
    	}
    }
    //TO
	driver.findElement(By.xpath("//div[@class='fsw_inputBox searchToCity inactiveWidget activeWidget']/label")).click();
	driver.findElement(By.xpath("//div[@class='hsw_autocomplePopup autoSuggestPlugin makeFlex column spaceBetween']/div/input")).sendKeys("Riyadh");
	List<WebElement> listcites2=driver.findElements(By.cssSelector("p[class='font14 appendBottom5 blackText']"));
for(int i=0;i<listcites2.size();i++) {
	String text=listcites2.get(i).getText();
	if(text.contains("Jeddah")){
		listcites2.get(i).click();
		break;
	}
}

//Step 4: Select the Departure date in Dec 2020													
driver.findElement(By.xpath("//span[contains(text(),'DEPARTURE')]")).click();
driver.findElement(By.xpath("//div[@class='DayPicker-Day'][contains(@aria-label, 'Dec 21 2021')]")).click();


//Step 5: Search for the cheapest price and click on Book now button													
driver.findElement(By.xpath("//a[text()='Search']")).click();
driver.findElement(By.xpath("//span[text()='Price']")).click();
driver.findElement(By.xpath("//*[@id='bookbutton-RKEY:e2a55635-be5f-4fe4-9de8-9f7b8c2c628d:1_0']/span[1]")).click();
driver.findElement(By.xpath("//*[@id='bookbutton-RKEY:e2a55635-be5f-4fe4-9de8-9f7b8c2c628d:1_0']")).click();

 
    
    
    
    
    
  }

}
